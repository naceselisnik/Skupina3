@extends('layouts.app')

@section('content')

<table>
<tr><td><img src="image/sevcnikar.jpg" width='70%'></td><td>
<img src="image/podkriznik.jpg" width='70%'></td><td>
<img src="image/aaa.jpg" width="65%"></td></tr>
<tr><td>Nejc Sevčnikar</td><td>Anej Podkrižnik</td><td>Nace Selišnik</td></tr>
</table> 

@endsection