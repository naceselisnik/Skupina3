<?php $__env->startSection('content'); ?>
       <center>
            <form action="/registrationForm" method="POST">
                <input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>">
                <h1>Registration: </h1>
                <label>Name:</label>
                <br>
                <input type="text" name="name" required="required" placeholder="James*">
                <br>
                <br>
                <label>Surname:</label>
                <br>
                <input type="text" name="surname" required="required" placeholder="Anderson*">
                <br>
                <br>
                <label>Mail:</label>
                <br>
                <input type="email" name="mail" required="required" placeholder="j.anderson@gmail.com*">
                <br>
                <br>
                <label>Password:</label>
                <br>
                <input type="password" name="password1" required="required" placeholder="Password*" maxlength="20">
                <br>
                <br>
                <label>Confirm Password:</label>
                <br>
                <input type="password" name="password2" required="required" placeholder="Confirm Password*" maxlength="20">
                <br>
                <br>
                <input type="submit" value="Sing Up">
                
            </form>
            
            </center>
   

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>