<?php $__env->startSection('content'); ?>
       <center>
            <form action="/updatevideo" method="POST">
                <input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>">
                <h1>Edit: </h1>
                <input type="hidden" name="id" value="<?php echo e($video->id); ?>"
                <label>Title:</label>
                <br>
                <input type="text" value="<?php echo e($video->title); ?>" name="newTitle" required="required" 
                placeholder="New Title" style="width:20%; height:50px; text-align:center;">
                <br>
                <br>
                <label>Description:</label>
                <br>
                <textarea maxlength="1000" name="newDescription" value="<?php echo e($video->description); ?>" required="required"  style="width:20%; height:300px; text-align:center";></textarea>
                <br>
                <br>
                <input type="submit" value="edit" style="width:20%; height:50px; border:1px solid black; text-align:center;">
                
            </form>
            
            </center>
   

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>