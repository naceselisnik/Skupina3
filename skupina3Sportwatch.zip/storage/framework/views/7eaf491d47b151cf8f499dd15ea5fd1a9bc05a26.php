<?php $__env->startSection('content'); ?>
<span style="color:black;">
nackov67j7vjjhkifcujxduxmdkmzm
dx
ghdf
h
hx
hxdf
hd
fx
fgj
hgk
gjhklgkghckfgcjdfhfnfgcj
fgxj
fxgj
fxgj
jgfx
</span>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>