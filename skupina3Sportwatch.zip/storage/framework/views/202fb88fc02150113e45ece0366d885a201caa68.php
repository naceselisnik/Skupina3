<?php $__env->startSection('content'); ?>
       <center>
            <form action="/updatevideo" method="POST">
                <input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>">
                <h1>Edit: </h1>
                <input type="hidden" name="id" value="<?php echo e($video->id); ?>"
                <label>Title:</label>
                <br>
                <input type="text" value="<?php echo e($video->title); ?>" name="newTitle" required="required" 
                placeholder="New Title">
                <br>
                <br>
                <label>Description:</label>
                <br>
                <input type="text" name="newDescription" value="<?php echo e($video->description); ?>" required="required" placeholder="New Description">
                <br>
                <br>
                <input type="submit" value="edit">
                
            </form>
            
            </center>
   

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>