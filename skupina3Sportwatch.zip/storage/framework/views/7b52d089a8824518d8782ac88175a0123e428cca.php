<?php $__env->startSection('content'); ?>
<?php if(Session::get('user_id')): ?>
	<h3>You are logged in as <?php echo e(Session::get('name')); ?> <?php echo e(Session::get('surname')); ?></h3>
<?php endif; ?>
<center>
<table>
<td><video width="720" height="360" preload="auto" controls="1">
 <source src="/<?php echo e($video->url); ?>" type="video/mp4" />
 <source src="/<?php echo e($video->url); ?>" type="video/webm" />
 <source src="/<?php echo e($video->url); ?>" type="video/ogg" />
 <p>Fallback text.</p>
 </video>
 </td></table>
<h1><?php echo e($video->title); ?></h1>
<h5><b>Upload date:</b></h5>
<span><?php echo e($video->created_at); ?></span><br><br>
 <a href='/editvideo/<?php echo e($video->id); ?>'>Edit Video</a> <br>
 <a href='/deletevideo/<?php echo e($video->id); ?>'>Delete Video</a> 

</center>



<?php $__env->stopSection(); ?>






<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>