<?php $__env->startSection('content'); ?>
       <center>
            <form action="/loggedIn" method="POST">
                <input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>">
                <h1>Login: </h1>
                
                <br>
                <input type="email" name="email" required="required" placeholder="Email" style="width:20%; height:50px; text-align:center;">
                <br>
                <br>
                <input type="password" name="password" required="required" placeholder="Password" maxlength="20" style="width:20%; height:50px; text-align:center;">
                <br>
                <br>
                <input type="submit" value="Sing In" style="width:20%; height:50px; border:1px solid black; text-align:center;">
                
            </form>
            
            </center>
   

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>