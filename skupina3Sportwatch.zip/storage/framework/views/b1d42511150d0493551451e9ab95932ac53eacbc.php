<?php $__env->startSection('content'); ?>
       <center>
            <form action="/editvideo" method="POST">
                <input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>">
                <h1>Login: </h1>
                
                <label>Title:</label>
                <br>
                <input type="text" name="newTitle" required="required" placeholder="New Title">
                <br>
                <br>
                <label>Description:</label>
                <br>
                <input type="text" name="newDescription" required="required" placeholder="New Description">
                <br>
                <br>
                <input type="submit" value="edit">
                
            </form>
            
            </center>
   

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>