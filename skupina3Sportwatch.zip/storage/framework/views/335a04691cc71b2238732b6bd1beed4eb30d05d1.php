<?php $__env->startSection('content'); ?>
<?php if(Session::get('user_id')): ?>
	<h3>You are logged in as <?php echo e(Session::get('name')); ?> <?php echo e(Session::get('surname')); ?></h3>
<?php endif; ?>

<table width="100%" border="1">
<?php $__currentLoopData = $videos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $video): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>



<tr><td width="25%" style="padding:120px 0;"><a href="/video/<?php echo e($video->id); ?>"><img src="<?php echo e($video->thumbnail); ?>" alt="Image not found" /></a>
<td><a href="/video/<?php echo e($video->id); ?>"> <b> <?php echo e($video -> title); ?> </b> </a><br>
<a href="/video/<?php echo e($video->id); ?>"> <?php echo e($video -> description); ?></a></td></tr>


<?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
</table>






<?php $__env->stopSection(); ?>



<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>