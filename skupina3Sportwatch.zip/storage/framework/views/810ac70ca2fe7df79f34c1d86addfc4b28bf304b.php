<!DOCTYPE html>
<!--[if lt IE 7 ]><html class="ie ie6" lang="en"> <![endif]-->
<!--[if IE 7 ]><html class="ie ie7" lang="en"> <![endif]-->
<!--[if IE 8 ]><html class="ie ie8" lang="en"> <![endif]-->
<!--[if (gte IE 9)|!(IE)]><!-->
<html lang="en">
<!--<![endif]-->
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">
    <meta name="description" content="">
    <meta name="author" content="">
    <!--[if IE]>
        <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
        <![endif]-->
    <title>FREE  BOOTSTRAP TEMPLATE - Relax </title>
    <!--REQUIRED STYLE SHEETS-->
    <!-- BOOTSTRAP CORE STYLE CSS -->
    <link href="css/bootstrap.css" rel="stylesheet" />
    <!-- FONTAWESOME STYLE CSS -->
    <link href="css/font-awesome.min.css" rel="stylesheet" />
    <!--ANIMATED FONTAWESOME STYLE CSS -->
    <link href="css/font-awesome-animation.css" rel="stylesheet" />
     <!--PRETTYPHOTO MAIN STYLE -->
    <link href="css/prettyPhoto.css" rel="stylesheet" />
       <!-- CUSTOM STYLE CSS -->
    <link href="css/style.css" rel="stylesheet" />
    <!-- GOOGLE FONT -->
    <link href='http://fonts.googleapis.com/css?family=Open+Sans' rel='stylesheet' type='text/css'>
    <!-- HTML5 shim and Respond.js IE8 support of HTML5 elements and media queries -->
    <!--[if lt IE 9]>
      <script src="https://oss.maxcdn.com/libs/html5shiv/3.7.0/html5shiv.js"></script>
      <script src="https://oss.maxcdn.com/libs/respond.js/1.3.0/respond.min.js"></script>
    <![endif]-->
    
</head>
<body >
         <!-- NAV SECTION -->
         <div class="navbar navbar-inverse navbar-fixed-top">
       
        <div class="container">
            <div class="navbar-header">
                <button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".navbar-collapse">
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                </button>
                <a class="navbar-brand" href="#">YOUR LOGO</a>
            </div>
            <div class="navbar-collapse collapse">
                <ul class="nav navbar-nav navbar-right">
                    <li><a href="#home-sec">HOME</a></li>
                    <li><a href="#services-sec">SERVICES</a></li>
                     <li><a href="#price-sec">PRICING</a></li>
                       <li><a href="#port-sec">PORTFOLIO</a></li>
                    <li><a href="#contact-sec">CONTACT</a></li>
                </ul>
            </div>
           
        </div>
    </div>
     <!--END NAV SECTION -->
    
    <!--HOME SECTION-->
    <div id="home-sec">

   
    <div class="container"  >
        <div class="row text-center">
            <div  class="col-md-12" >
                <span class="head-main" >Go Relax Template</span>
                <h2 class="head-sub-main">Download And Get Relaxed</h2>
                <h3 class="head-last col-md-4 col-md-offset-4  col-sm-6 col-sm-offset-3">Lorem ipsum dolor sit ametLorem</h3>
         
                 
            </div>
            <div class="col-md-12 col-sm-12">
               
                <a  href="#services-sec">
                 <i class="fa fa-crosshairs fa-5x go-marg"></i> 
                    </a>
            </div>
        </div>
    </div>
         </div>
    
    <!--END HOME SECTION-->  

    <!--SERVICES SECTION-->    
    <section  id="services-sec">
        <div class="container">
            <div class="row ">
                <h1 class="g-pad-bottom">  <i class="fa fa-crosshairs "></i> Our Services  </h1>
                
               
                <div class="text-center g-pad-bottom">
                    <div class="col-md-4 col-sm-4">
                            <i class="fa fa-fire-extinguisher fa-5x faa-vertical animated c-main "></i>
                            <h4>Free To Use </h4>
                            <p>
                                Lorem ipsum dolor sit amet, consectetur adipiscing elit.
                         Curabitur nec nisl odio. Mauris vehicula at nunc id posuere.
                                Lorem ipsum dolor sit amet, consectetur adipiscing elit.
                            </p>
                            
                    </div>
                    <div class="col-md-4 col-sm-4">
                            <i class="fa fa-coffee fa-5x faa-ring animated c-main "></i>
                            <h4>100%  Responsive </h4>
                            <p>
                                Lorem ipsum dolor sit amet, consectetur adipiscing elit.
                         Curabitur nec nisl odio. Mauris vehicula at nunc id posuere.
                                 Lorem ipsum dolor sit amet, consectetur adipiscing elit.
                            </p>
                            
                    </div>
                   
                    <div class="col-md-4 col-sm-4">
                            <i class="fa fa-gavel fa-5x faa-shake animated c-main "></i>
                            <h4>Clean & Customizable </h4>
                            <p>
                                Lorem ipsum dolor sit amet, consectetur adipiscing elit.
                         Curabitur nec nisl odio. Mauris vehicula at nunc id posuere.
                                Lorem ipsum dolor sit amet, consectetur adipiscing elit.
                            </p>
                          
                    </div>
                </div>
                  </div>
                <div class="row">
                  
                    <div class="col-md-4 col-sm-4">
                          <div class="panel panel-default">
                       
                        <div class="panel-body">
                             <h4 class="adjst">Lorem ipsum dolor sit amet </h4>
                            <p>
                                   Lorem ipsum dolor sit amet, consectetur adipiscing elit.
                         Curabitur nec nisl odio. Mauris vehicula at nunc id posuere.
                                </p>
                             
                            
                        </div>
                    </div> 
                            
                    </div>
                   <div class="col-md-4 col-sm-4">
                          <div class="panel panel-default">
                       
                        <div class="panel-body">
                             <h4 class="adjst">Lorem ipsum dolor sit amet </h4>
                            <p>
                                   Lorem ipsum dolor sit amet, consectetur adipiscing elit.
                         Curabitur nec nisl odio. Mauris vehicula at nunc id posuere.
                                </p>
                             
                            
                        </div>
                    </div> 
                            
                    </div>
                     <div class="col-md-4 col-sm-4">
                          <div class="panel panel-default">
                       
                        <div class="panel-body">
                             <h4 class="adjst">Lorem ipsum dolor sit amet </h4>
                            <p>
                                   Lorem ipsum dolor sit amet, consectetur adipiscing elit.
                         Curabitur nec nisl odio. Mauris vehicula at nunc id posuere.
                                </p>
                             
                            
                        </div>
                    </div> 
                            
                    </div>
                </div>
          
        </div>
    </section>
    <!--END SERVICES SECTION-->
  
     <!--PRICE SECTION-->
    <section id="price-sec">
        <div class="container">
            <div class="row g-pad-bottom">
                <h1 class="g-pad-bottom">  <i class="fa fa-crosshairs "></i> Our Pricing </h1>
                
                  
                <div class="col-md-12 text-center ">
                    <div class="col-md-4 col-sm-4">
                        <ul class="plan">
                             
                            <li class="plan-head">BASIC <i class="fa fa-dot-circle-o  c-pr-i"></i> PLAN</li>
                           
                            <li><strong>52</strong> Emails</li>
                            <li><strong>50 GB</strong> Space</li>
                            <li><strong>Free</strong> Support</li>
                             <li class="main-price">$99 <small> * only</small></li>
                            <li class="bottom">
                                <a href="#" class="btn btn-success btn-lg ">BUY NOW</a>
                            </li>
                        </ul>
                    </div>
                    <div class="col-md-4 col-sm-4">
                        <ul class="plan">
                            <li class="plan-head">MEDIUM <i class="fa fa-dot-circle-o  c-pr-i"></i> PLAN</li>
                            
                            <li><strong>52</strong> Emails</li>
                            <li><strong>50 GB</strong> Space</li>
                            <li><strong>Free</strong> Support</li>
                            <li class="main-price">$199<small> * only</small></li>
                            <li class="bottom">
                                <a href="#" class="btn btn-primary btn-lg ">BUY NOW</a>
                            </li>
                        </ul>
                    </div>
                    <div class="col-md-4 col-sm-4">
                        <ul class="plan">
                            <li class="plan-head">VALUE <i class="fa fa-dot-circle-o  c-pr-i"></i> PLAN</li>
                         
                            <li><strong>52</strong> Emails</li>
                            <li><strong>50 GB</strong> Space</li>
                            <li><strong>Free</strong> Support</li>
                               <li class="main-price">$299 <small> * only</small></li>
                            <li class="bottom">
                                <a href="#" class="btn btn-danger btn-lg">BUY NOW</a>
                            </li>
                        </ul>
                    </div>
                

                </div>
            </div>


        </div>
    </section>
    <!-- END PRICE SECTION-->

     <!-- PORTFOLIO SECTION-->
   <section id="port-sec">
       <div class="container">
           <div class="row g-pad-bottom" >
                 <h1 class="g-pad-bottom">  <i class="fa fa-crosshairs"></i> Our Portfolio  </h1>
               
                <div class="col-md-10 col-md-offset-1 col-sm-12" >
                    <ul class="portfolio-items col-3">
                        <li class="portfolio-item">
                            <div class="item-main">
                                <div class="portfolio-image">
                                    <img src="assets/img/portfolio/thumb/t1.png" alt="">
                                    <div class="overlay">
                                        <a class="preview btn btn-danger" title="Image Title Here" href="assets/img/portfolio/big/b1.png"><i class=" fa fa-eye"></i></a>
                                    </div>
                                </div>
                                <h5>Lorem ipsum dolor sit amet</h5>
                            </div>
                        </li>
                       
                        <li class="portfolio-item">
                            <div class="item-main">
                                <div class="portfolio-image">
                                    <img src="assets/img/portfolio/thumb/t2.png" alt="">
                                    <div class="overlay">
                                        <a class="preview btn btn-danger" title="Image Title Here" href="assets/img/portfolio/big/b2.png"><i class=" fa fa-eye"></i></a>
                                    </div>
                                </div>
                                <h5>Lorem ipsum dolor sit amet</h5>
                            </div>
                        </li>
                        <li class="portfolio-item">
                            <div class="item-main">
                                <div class="portfolio-image">
                                    <img src="assets/img/portfolio/thumb/t3.png" alt="">
                                    <div class="overlay">
                                        <a class="preview btn btn-danger" title="Image Title Here" href="assets/img/portfolio/big/b3.png"><i class=" fa fa-eye"></i></a>
                                    </div>
                                </div>
                                <h5>Lorem ipsum dolor sit amet</h5>
                            </div>
                        </li>
                        <li class="portfolio-item">
                            <div class="item-main">
                                <div class="portfolio-image">
                                    <img src="assets/img/portfolio/thumb/t4.png" alt="">
                                    <div class="overlay">
                                        <a class="preview btn btn-danger" title="Image Title Here" href="assets/img/portfolio/big/b4.png"><i class=" fa fa-eye"></i></a>
                                    </div>
                                </div>
                                <h5>Lorem ipsum dolor sit amet</h5>
                            </div>
                        </li>
                        <li class="portfolio-item">
                            <div class="item-main">
                                <div class="portfolio-image">
                                    <img src="assets/img/portfolio/thumb/t5.png" alt="">
                                    <div class="overlay">
                                        <a class="preview btn btn-danger" title="Image Title Here" href="assets/img/portfolio/big/b5.png"><i class=" fa fa-eye"></i></a>
                                    </div>
                                </div>
                                <h5>Lorem ipsum dolor sit amet</h5>
                            </div>
                        </li>
                        <li class="portfolio-item ">
                            <div class="item-main">
                                <div class="portfolio-image">
                                    <img src="assets/img/portfolio/thumb/t6.png" alt="">
                                    <div class="overlay">
                                        <a class="preview btn btn-danger" title="Image Title Here" href="assets/img/portfolio/big/b6.png"><i class=" fa fa-eye"></i></a>
                                    </div>
                                </div>
                                <h5>Lorem ipsum dolor sit amet</h5>
                            </div>
                        </li>
                        <li class="portfolio-item ">
                           <div class="item-main">
                                <div class="portfolio-image">
                                    <img src="assets/img/portfolio/thumb/t7.png" alt="">
                                    <div class="overlay">
                                        <a class="preview btn btn-danger" title="Image Title Here" href="assets/img/portfolio/big/b7.png"><i class=" fa fa-eye"></i></a>
                                    </div>
                                </div>
                                <h5>Lorem ipsum dolor sit amet</h5>
                            </div>
                        </li>
                        <li class="portfolio-item ">
                           <div class="item-main">
                                <div class="portfolio-image">
                                    <img src="assets/img/portfolio/thumb/t8.png" alt="">
                                    <div class="overlay">
                                        <a class="preview btn btn-danger" title="Image Title Here" href="assets/img/portfolio/big/b8.png"><i class=" fa fa-eye"></i></a>
                                    </div>
                                </div>
                                <h5>Lorem ipsum dolor sit amet</h5>
                            </div>
                        </li>
                         <li class="portfolio-item">
                            <div class="item-main">
                                <div class="portfolio-image">
                                    <img src="assets/img/portfolio/thumb/t9.png" alt="">
                                    <div class="overlay">
                                        <a class="preview btn btn-danger" title="Image Title Here" href="assets/img/portfolio/big/b9.png"><i class=" fa fa-eye"></i></a>
                                    </div>
                                </div>
                                <h5>Lorem ipsum dolor sit amet</h5>
                            </div>
                        </li>
                    </ul>
                </div>
           </div>
       </div>
   </section>
     <!-- END PORTFOLIO SECTION-->
    <!--CONTACT SECTION-->
    
    <section  id="contact-sec">
        <div class="container">
             
            <div class="row g-pad-bottom">
                  <h1 class="g-pad-bottom">  <i class="fa fa-crosshairs"></i> Contact Info  </h1>
                
                  
                <div class="col-md-6 ">
                    <h2>Lorem ipsum dolor sit amet</h2>
                 
                    <p>
                         <strong> Address: </strong> &nbsp;Newyork City, Your Country, Pin-000000.  
                        <br />
                        Lorem ipsum dolor sit amet, consectetur adipiscing elit.
                         Curabitur nec nisl odio. Mauris vehicula at nunc id posuere.
                           Lorem ipsum dolor sit amet, consectetur adipiscing elit.
                         Curabitur nec nisl odio. Mauris vehicula at nunc id posuere.              
                    </p>
                    <form>
                        <div class="row">
                            <div class="col-md-6 ">
                                <div class="form-group">
                                    <input type="text" class="form-control" required="required" placeholder="Name">
                                </div>
                            </div>
                            <div class="col-md-6 ">
                                <div class="form-group">
                                    <input type="text" class="form-control" required="required" placeholder="Email address">
                                </div>
                            </div>
                        </div>
                        <div class="row">
                            <div class="col-md-12 ">
                                <div class="form-group">
                                    <textarea name="message" id="message" required="required" class="form-control" rows="3" placeholder="Message"></textarea>
                                </div>
                                <div class="form-group">
                                    <button type="submit" class="btn btn-success">Submit Request</button>
                                </div>
                            </div>
                        </div>
                    </form>
                </div>
                <div class="col-md-6">
                   <iframe class="cnt" src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d2999841.293321206!2d-75.80920404999999!3d42.75594204999997!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x4ccc4bf0f123a5a9%3A0xddcfc6c1de189567!2sNew+York!5e0!3m2!1sen!2s!4v1395313088825" s ></iframe>

                </div>
            </div>
        </div>
    </section>
    <!--END CONTACT SECTION-->

   

    <!--FOOTER SECTION -->
    <div id="footer">
        2014 www.yourdomain.com | All Right Reserved  
         
    </div>
    <!-- END FOOTER SECTION -->

    <!-- JAVASCRIPT FILES PLACED AT THE BOTTOM TO REDUCE THE LOADING TIME  -->
    <!-- CORE JQUERY  -->
    <script src="js/jquery-1.10.2.js"></script>
    <!-- BOOTSTRAP CORE SCRIPT   -->
    <script src="js/plugins/bootstrap.min.js"></script>  
     <!-- ISOTOPE SCRIPT   -->
    <script src="js/jquery.isotope.min.js"></script>
    <!-- PRETTY PHOTO SCRIPT   -->
    <script src="js/jquery.prettyPhoto.js"></script>    
    <!-- CUSTOM SCRIPTS -->
    <script src="js/custom.js"></script>

</body>
</html>
