<?php $__env->startSection('content'); ?>
       <center>
            <form action="/loggedIn" method="POST">
                <input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>">
                <h1>Login: </h1>
                
                <label>Mail:</label>
                <br>
                <input type="email" name="email" required="required" placeholder="j.anderson@gmail.com*">
                <br>
                <br>
                <label>Password:</label>
                <br>
                <input type="password" name="password" required="required" placeholder="Password*" maxlength="20">
                <br>
                <br>
                <input type="submit" value="Sing In">
                
            </form>
            
            </center>
   

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>