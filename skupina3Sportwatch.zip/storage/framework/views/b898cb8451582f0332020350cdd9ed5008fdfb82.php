<?php $__env->startSection('content'); ?>
<?php if(Session::get('user_id')): ?>
	<h3>You are logged in as <?php echo e(Session::get('name')); ?> <?php echo e(Session::get('surname')); ?></h3>
<?php endif; ?>
<center>
<table>
<td><video width="720" height="360" preload="auto" controls="1">
 <source src="/<?php echo e($video->url); ?>" type="video/mp4" />
 <source src="/<?php echo e($video->url); ?>" type="video/webm" />
 <source src="/<?php echo e($video->url); ?>" type="video/ogg" />
 <p>Fallback text.</p>
 </video>
 </td></table>
<h1><?php echo e($video->title); ?></h1>
<h5><b>Upload date:</b></h5>
<span><?php echo e($video->created_at); ?></span><br><br>
<?php if(Session::get('user_id') == $video->user_id): ?>
 <a href='/editvideo/<?php echo e($video->id); ?>'>Edit Video</a> <br>
 <a href='/deletevideo/<?php echo e($video->id); ?>'>Delete Video</a> <br>
<?php endif; ?>

<table border=1>
<tr><td><?php if(Session::get('user_id')): ?>
<a href="/video/<?php echo e($video->id); ?>/like">
<?php endif; ?>
<img src="../image/up.jpg" width="100px" height="100px"></a></td><td>
<?php if(Session::get('user_id')): ?>
<a href="/video/<?php echo e($video->id); ?>/dislike">
<?php endif; ?>
<img src="../image/down.jpg" width="100px" height="100px"></a></td></tr>
<tr style="height:10px"><td><?php echo e($likes); ?></td><td><?php echo e($dislikes); ?></td></tr>
</table><hr class="hr">
<h1>Comments</h1>
<form action="/video/<?php echo e($video->id); ?>/comment/" method="POST">
<input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>">
	<table width="50%">
		<tr>
			<td>
				<textarea name="textbox" rows="4" max cols="30" class="fit"></textarea>
			</td>	
		</tr>
	</table>
	<input type="submit" value="Comment">
</form><hr class="hr">
<table width="50%" class=" comments">
<tr>
		<?php $__currentLoopData = $comments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $comment): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
	<td style=" text-align: left;">
		<b><?php echo e($comment->user); ?>:</b><br>
	</td>
	<td>
		<?php echo e($comment->comment); ?>

		<?php if(Session::get('user_id') == $comment->user_id): ?>
		<a href='/deletecomment/<?php echo e($comment->id); ?>' class="deletecomment">Delete Video</a> <br>
		<?php endif; ?>
	</td>
</tr>
<?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
</table>
</center>

<?php $__env->stopSection(); ?>






<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>