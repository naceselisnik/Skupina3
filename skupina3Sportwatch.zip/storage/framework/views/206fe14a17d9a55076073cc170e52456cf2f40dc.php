<?php $__env->startSection('content'); ?>

<table>
<tr><td><img src="image/sevcnikar.jpg" width='70%'></td><td>
<img src="image/podkriznik.jpg" width='70%'></td><td>
<img src="image/aaa.jpg" width="65%"></td></tr>
<tr><td>Nejc Sevčnikar</td><td>Anej Podkrižnik</td><td>Nace Selišnik</td></tr>
</table> 

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>