<?php $__env->startSection('content'); ?>
<?php if(Session::get('user_id')): ?>
	<h3>Prijavljeni ste kot <?php echo e(Session::get('name')); ?> <?php echo e(Session::get('surname')); ?></h3>
<?php endif; ?>
<img src="http://akademija.uns.ac.rs/wp-content/uploads/2012/03/slika2011.jpg">
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>