<?php $__env->startSection('content'); ?>
<?php if(Session::get('user_id')): ?>
	<h3>You are logged in as <?php echo e(Session::get('name')); ?> <?php echo e(Session::get('surname')); ?>

	<?php if(Session::get('admin') == 1): ?>
		(admin)
	<?php endif; ?>
	</h3>
<?php endif; ?>
<hr>

<table width="100%" border="0">
<?php $__currentLoopData = $videos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $video): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>



<tr><td width="25%" ><a href="/video/<?php echo e($video->id); ?>">
<div class="container1">
  <img src="/<?php echo e($video->thumbnail); ?>" alt="Image not found" class="image1"  height="300px" width="300px">
  <div class="overlay1">
    <div class="text1"><?php echo e($video -> title); ?></div>
  </div>
</div>
</a>
<td style="text-align:left;"> <a href="/video/<?php echo e($video->id); ?>" style="font-size:30px;  text-transform: uppercase;"> <b> <?php echo e($video -> title); ?> </b> </a><br>
<a href="/video/<?php echo e($video->id); ?>"> <?php echo e($video -> description); ?></a>  
<hr>
<div style="text-align: right">
<?php echo e($video->created_at); ?></div>
</td>
</tr>
<tr> <td colspan="2"><hr></td> </tr>

<?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>

</table>



<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>