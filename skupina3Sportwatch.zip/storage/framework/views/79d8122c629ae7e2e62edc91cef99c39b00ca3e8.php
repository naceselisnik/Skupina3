<?php $__env->startSection('content'); ?>
<div id="loggedIn">
<h3>You are logged in as <?php echo e($name); ?> <?php echo e($surname); ?>!</h3>
<ul>
<li><a href="objavi">UPLOAD VIDEO</a></li>
<li><a href="objavi">DELETE VIDEO</a></li>
</ul>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>